package com.encuesta.principal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Registros extends AppCompatActivity {

    private TextView pantalla;
    ListView mlistView;
    Button recargar;
    TextView buscarId;
    RequestQueue requestQueue;
    private List<String> mLista = new ArrayList<>();
    private ArrayAdapter<String>  miAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registros);
        recargar = findViewById(R.id.recargar);
        buscarId = findViewById(R.id.buscarId);// inicializar variable, con buscarId que esta en actibity_registro

        pantalla = findViewById(R.id.pantalla);
        mlistView = findViewById(R.id.listaDatos);
        //mlistView.setOnItemClickListener(this);

        requestQueue = Volley.newRequestQueue(this);

        //datos();

    }

    public void buttonRecargarDos(View v){
        String bb = buscarId.getText().toString().trim();
        jsonArregloOjetos(bb);
    }

    public void datos() {
        String URL1 = "https://yeniuno.000webhostapp.com/fetch.php?id=29";
        StringRequest request = new StringRequest(
                Request.Method.GET,
                URL1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pantalla.setText(response.toString().trim());
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        requestQueue.add(request);
    }

    private void jsonArregloOjetos(String bb) {
        String url = "https://yeniuno.000webhostapp.com/fetch.php?id=".concat(bb);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        //pantalla.setText("");
                        try {
                            String id = response.getString("id_encuesta");
                            String nombre = response.getString("nombre_encuesta");
                            int edad = response.getInt("edad_encuesta");
                            String telefono = response.getString("phone_encuesta");
                            String genero = response.getString("gene_encuesta");
                            String lenguaje = response.getString("lenguaje_encuesta");

                            pantalla.append("ID: " + id + "\n");
                            pantalla.append("Nombre: " + nombre + "\n");
                            pantalla.append("Edad: " + edad + "\n");
                            pantalla.append("Teléfono: " + telefono + "\n");
                            pantalla.append("Género: " + genero + "\n");
                            pantalla.append("Lenguaje: " + lenguaje + "\n");



                            mLista.add(nombre);
                            //mLista.add("nombre");
                            mlistView.setAdapter(miAdapter);



                            //pantalla.setText(response.toString());
                            Toast.makeText(Registros.this, "Entro....", Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }}},
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Registros.this, "Error no Conectado..", Toast.LENGTH_SHORT).show();
                    }});

        requestQueue.add(jsonObjectRequest);

        miAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,mLista);
        //mlistView.setAdapter(miAdapter);


    }





}