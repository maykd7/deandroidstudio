package com.encuesta.principal;


import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;



import java.util.HashMap;
import java.util.Map;

public class Formulario extends AppCompatActivity {

    TextView tName, tOld, tPhone, tGenero, tLenguaje;
    Button bGuardar;
    RequestQueue requestQueue;
    RadioButton rbMujer;

    RadioButton rbSi;



    private static final String URL1 = "https://yeniuno.000webhostapp.com/save.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        requestQueue = Volley.newRequestQueue(this);

        intUI();
    }

    private void intUI(){
        tName = findViewById(R.id.editTextNombre);
        tOld = findViewById(R.id.editTextEdad);
        tPhone = findViewById(R.id.editTextTelefono);

        bGuardar = findViewById(R.id.buttonGuardar);

        rbMujer = findViewById(R.id.radioButtonMujer);

        rbSi= findViewById(R.id.radioButtonSi);

    }

    public void guardar(View v){
        String name = tName.getText().toString().trim();
        String old = tOld.getText().toString().trim();
        String phone = tPhone.getText().toString().trim();
        String gene;
        String lengu;

        if(rbMujer.isChecked()){
            gene = "Mujer";
        }
        else gene = "Hombre";

        if(rbSi.isChecked()){
            lengu = "Si";
        }
        else lengu = "No";


        crearUsuarios(name, old, phone, gene, lengu);
    }

    private void crearUsuarios(final String name, final String old, final String phone, final String gene, final String lengu) {

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Formulario.this, "Guardando..", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Formulario.this, "Error no Guardado..", Toast.LENGTH_SHORT).show();
                        //Toast.makeText(Formulario.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError{
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("old", old);
                params.put("phone", phone);
                params.put("gene" ,gene);
                params.put("lengu" ,lengu);

                return params;
            }

        };
        requestQueue.add(stringRequest);

    }

}